<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Course extends Model
{
      public function country()
    {
        return $this->belongsTo('App\Department');
    }
      public $fillable=['name','status','dept_id'];
}
