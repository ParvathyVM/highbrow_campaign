<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Officestaff extends Model
{
     public $fillable=['fname','lname','dob','gender','join_date','department','designation','house_name','place','country','state','district','qualification','mobile','email','image','password','status'];

}
