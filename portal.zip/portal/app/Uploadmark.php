<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Uploadmark extends Model
{
    protected $table = 'marks'; 
    public $fillable=['dept','course','sem','sub_name','dept_id','course_id','semester_id','stud_name','stud_id','typeexam','marks','total'];
}
