<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Apptitudes extends Model
{
    public $fillable=['question','opta','optb','optc','optd','dept','answer','course','sem','dept_id','course_id','sem_id','sub','sub_id'];
}
