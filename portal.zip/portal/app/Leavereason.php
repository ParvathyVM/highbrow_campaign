<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Leavereason extends Model
{
    public $fillable=[
		'email',
		'date',
		'reason',
		'status',
		];
}
