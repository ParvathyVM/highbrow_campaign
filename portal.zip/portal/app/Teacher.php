<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Teacher extends Model
{
    public $fillable=['fname','lname','dob','gender','dept','qualification','join_date','house_name','place','country','state','district','mobile','email','duty','image','password','status'];

}
