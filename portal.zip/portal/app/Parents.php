<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Parents extends Model
{
     public $fillable=['fname','lname','gender','adm_no','student','house_name','place','country','state','district','occupation','mobile','email','image','password','status'];

}
