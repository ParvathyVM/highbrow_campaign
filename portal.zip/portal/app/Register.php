<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Register extends Model
{
     public $fillable=['adm_no','reg_no','fname','lname','dob','gender','adm_date','pass_date','religion','house_name','place','district','state','country','mobile','email','tenth','plus_two','degree','department','stream','semester','image','password','status','payment'];
}
?>

