<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class QuestionUpload extends Model
{
    protected $table='questionuploads';
    public $fillable=['id','dept','course','sem','description','question_upload'];
}
