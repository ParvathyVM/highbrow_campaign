<?php

namespace App\Http\Controllers;
use DB;
use Illuminate\Http\Request;

class StudentprofileController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function view(register $register, Request $request)
    {
    
        $username=$request->session()->get('email');
        $users=DB::table('registers')->where(['email'=>$username])->get();
        return view('students.profile',compact('users'));
    }
   
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $data=Register::find($email);
        return view('students.editprofile',compact('data'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        $unm = $request->session()->get('email');
		
        $fname=$request->input('u_name');
        $lname=$request->input('l_name');
		$umob=$request->input('mobile');
		$address=$request->input('address');
		$upost=$request->input('post');
		$ucity=$request->input('city');
		$udist=$request->input('district');
        $ustate=$request->input('state');
       
		DB::table('registers')->where('email',$unm)->update(array(
        'fname'=>$fname,'lname'=>$lname,'mobile'=>$umob,'house_name'=>$address,'department'=>$upost,
)); 
		return redirect('/profile1');
       //return redirect()->back()->with('success', 'Updated Your Profile');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function profile_edit(Request $request)
    {
		$unm = $request->session()->get('email');
		
		//$check=DB::table('registers')->where(['email'=>$unm])->get();
		$data = DB::table('registers')->where(['email'=>$unm])->get();
        return view('students.profile',compact('data'));
    }

    public function haiii(Request $request)
    {
		$unm = $request->session()->get('email');
		
		//$check=DB::table('registers')->where(['email'=>$unm])->get();
		$data = DB::table('registers')->where(['email'=>$unm])->get();
        return view('students.editprofile',compact('data'));
    }

    public function destroy($id)
    {
        //
    }
    
}
