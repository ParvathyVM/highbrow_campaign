<?php
$con=mysqli_connect("localhost","root","");
mysqli_select_db($con,"angular");
/*if(!$con)
{
	echo "not success";
}
	else
	{
		echo "success";
	}*/
	
?>

