<?php

namespace App\Http\Controllers;
use DB;
use PDF;
use Illuminate\Support\Facades\Input;
use App\Register;

use Illuminate\Http\Request;

class SearchStudentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $unm = $request->session()->get('email');
		
		//$check=DB::table('registers')->where(['email'=>$unm])->get();
        $data = DB::table('faculties')->where(['email'=>$unm])->get();
        $datas = DB::table('invigilators')->where(['email'=>$unm])->paginate(5);
        $departments = DB::table("departments")->where('status','active')->pluck("name","id");
		return view('faculty.searchstudent',compact('data','departments'));
    }

    public function getCourseList(Request $request)
    {
        $courses = DB::table("courses")
        ->where("dept_id",$request->dept_id)->where("status",'active')
        ->pluck("name","id");
        return response()->json($courses);
    }
    public function getStreamList(Request $request)
    {
        $streams= DB::table("semesters")
        ->where("course_id",$request->course_id)
        ->pluck("name","id");
        return response()->json($streams);
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function search(Request $request)
    {
        $unm = $request->session()->get('email');
		
		//$check=DB::table('registers')->where(['email'=>$unm])->get();
        $data = DB::table('faculties')->where(['email'=>$unm])->get();
        $passyear = Input::get ( 'year' );
        $dept = Input::get ( 'dept' );
        $course = Input::get ( 'course' );
        $sem = Input::get ( 'semester' );
    $user = Register::where('passyear','LIKE','%'.$passyear.'%')->Where('dept','LIKE','%'.$dept.'%')->Where('course','LIKE','%'.$course.'%')->Where('sem','LIKE','%'.$sem.'%')->limit(10)->get();
    if(count($user) > 0){
        
    
    
        return view('faculty.searchresult',compact('data'))->withDetails($user)->withQuery ( $passyear, $dept, $course, $sem );
        // $pdf = PDF::loadView('faculty.searchresult');
        // return $pdf->download('report.pdf');
    }
        else 


    return redirect()->back()->with('success', 'Not Found');
    }

    public function fun_pdf(Request $request)

    {
        $unm = $request->session()->get('email');
		
		//$check=DB::table('registers')->where(['email'=>$unm])->get();
        $data = DB::table('faculties')->where(['email'=>$unm])->get();

        $pdf = PDF::loadView('faculty.searchresult',compact('data'));
        return $pdf->download('report.pdf');

    }
    
    public function exportExcel()
    {
      return Excel::download(new ListExport, 'list.xlsx');
    }
       
    }

