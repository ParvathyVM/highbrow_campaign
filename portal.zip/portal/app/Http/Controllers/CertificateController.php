<?php

namespace App\Http\Controllers;
use DB;
use App\Certificate;
use Illuminate\Http\Request;

class CertificateController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $unm = $request->session()->get('email');
		
		//$check=DB::table('registers')->where(['email'=>$unm])->get();
        $data = DB::table('registers')->where(['email'=>$unm])->get();
        //$datas = DB::table('invigilators')->where(['email'=>$unm])->paginate(5);
        return view('students.certificate',compact('data'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $unm = $request->session()->get('email');
        // $unames=DB::table('registers')->select(DB::raw("CONCAT (fname,' ',lname) as fullname"))
        // ->orderBy('lname','ASC')
        // ->where(['email'=>$unm])->first();
        $certificate=new Certificate([
            'email'=>$request->get('email'),
            'certificate'=>$request->get('certificate'),
            'date'=>$request->get('date'),
            'reason'=>$request->get('desc'),
            'status'=>"Not approved",
        ]);
        $certificate->save();
        
//         $email1= DB::table('parents')
//         ->join('registers','registers.id','=','parents.adm_no')
//         ->select('parents.email')->get();
// $uname=$unames->fullname;
//         $email=$email1;
//         $subject="Leave Applied";
//    $message="Applied for leave By".$uname;
   
//            Mail::to($email)->send(new SendEmail($subject,$message));					 
  
//    return redirect()->back()->with('success', 'Leave Applied');
     
        return redirect()->back()->with('success', 'Applied for certificate');
    }
    public function store1(Request $request)
    {
        $leave=new Leavereason([
            'email'=>$request->get('email'),
            'date'=>$request->get('date'),
            'reason'=>$request->get('desc'),
        ]);
        $leave->save();
        return redirect()->back()->with('success', 'Leave Applied ');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Certificate  $certificate
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request)
    {
        $username=$request->session()->get('email');
        $data=DB::table('certificates')->where(['email'=>$username])->get();
       
        $studs=DB::select('select * from certificates');
        return view('staff.certi',compact('studs','data'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Certificate  $certificate
     * @return \Illuminate\Http\Response
     */
    public function edit(Certificate $certificate)
    {
        $data = Certificate::where('email', $id)->get();
        $user= Certificate::where('email', $id)->update(['status'=> 'Approved']);
    }
    
    public function des($email,$status)
    {
            //  $datas = Certificate::where('email', $email)->get();
                   
                  //  foreach($datas as $obj){
                     if($status == "Not Approved"){
                        Certificate::where('email', $email)->update(['status'=> 'approved']);
                          
                        }
                        else if($status == "approved")
                        {
                            Certificate::where('email',$email)->update(['status'=> 'Not Approved']);
                           
                        }
      
            return redirect('/certi');
            }
        
    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Certificate  $certificate
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Certificate $certificate)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Certificate  $certificate
     * @return \Illuminate\Http\Response
     */
    public function destroy(Certificate $certificate)
    {
        //
    }
}
