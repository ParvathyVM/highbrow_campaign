<?php

namespace App\Http\Controllers;

use App\Officestaff;
use Illuminate\Http\Request;
use DB;
use Crypt;
use Hash;
use Mail;
use App\Mail\SendEmail;
use App\Login;
class OfficestaffController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
	  public function view(Request $request)
    {
		//$unm = $request->session()->get('username');
		//$users=Register::all();
		 $users = Officestaff::paginate(5);
		//$users = DB::select('select * from registers')->get();
		 //$users=DB::table('registers')->where(['email'=>$unm])->get();
      return view('admin.editstaff',compact('users'));
	
		//$items = DB::table('registers')->get();
		//return view('admin.manage_student',compact('students'));
	}
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        $filename6=$request->img1->getClientOriginalName();
		$request->img1->storeAs('public/upload',$filename6);
 
        $uname=$request->input('mail');
		//$msg="";
		 $check=DB::table('officestaffs')->where(['email'=>$uname])->get();

		 if(count($check)==0)
		
		{
                      $users=new Officestaff([
					  // 'reg_no'=>$request->get('regno'),
						 'fname'=>$request->get('firstname'),
						 'lname'=>$request->get('lastname'),
	                     'dob'=>$request->get('dob'),
						 'gender'=>$request->get('gender'),

						 'join_date'=>$request->get('joindate'),
						 'department'=>$request->get('department'),
						 'designation'=>$request->get('designation'),						 
						 'house_name'=>$request->get('house'),
						 'place'=>$request->get('place'),
						 'country'=>$request->get('country'),
						 'state'=>$request->get('state'),
						 'district'=>$request->get('district'),
						 'qualification'=>$request->get('qualification'),
						 'mobile'=>$request->get('mobileno'),
						 'email'=>$request->get('mail'),
                         'image'=>$filename6,
	                    // 'duty'=>$request->get('duty'),
	                     //'sclass'=>$request->get('sclass'),
						 
						// 'username'=>$request->get('username'),
						// 'password'=>$request->get('password'),
						 //'image'=>$request->get('imageico'),
						 'status'=>1
	                  ]);
					  $users->save();
					  	 //echo "haii";
					  $name=$request->input('firstname');
					  $hpwd = Hash::make($request->input('password'));
					 $pwd=$request->input('password');
					  //$conpwd=$request->input('conpassword');
					 
					 // if ($pwd==$conpwd)
    
                     //{             
					     $result=DB::insert("insert into logins(email,password,fname,role,status)values(?,?,?,?,?)",[$uname,$hpwd,$name,4,1]);
					    // return view('admin.home');
						//return redirect()->back()->with('success','successfully added');
                        $email=$uname;
						$subject="New registration";
                   $message="Now You are the part of the Institution 
                   Your username is :".$email."
                        <br>
                   password is :". $pwd;
                           Mail::to($email)->send(new SendEmail($subject,$message));					 
                   // return redirect('/')->with('alert', 'Now You are the part of Guruvayoor Devout Cabinet, check your mail for more details');


                   return redirect()->back()->with('success', 'Staff Added and Sended Email too');

		             //}  
                     //else
                     //{
						//$msg= "not match";
						 //return view('welcome');
					 //}	
					 	
		}	
		else
		{
			         //    $msg= "User Already Registered";
						 
						return redirect('/already');
		}	
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Officestaff  $officestaff
     * @return \Illuminate\Http\Response
     */
    public function show(Officestaff $officestaff)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Officestaff  $officestaff
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $staff=Officestaff::find($id);
	 return view('admin.editstaff',compact('staff'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Officestaff  $officestaff
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
         $staff=Officestaff::find($id);
	   $staff->firstname=$request->get('firstname');
	   $staff->lastname=$request->get('lastname');
		
		$staff->house=$request->get('house');
		$staff->mobile=$request->get('mobile');
		$staff->department=$request->get('department');
		$staff->designation=$request->get('designation');
		//$staff->qualification=$request->get('qualification');
		//$faculty->qualification=$request->get('qualification');
		
		$staff->email=$request->get('email');
	  
	 
	   $staff->save();
	   return redirect('/manage');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Officestaff  $officestaff
     * @return \Illuminate\Http\Response
     */
    public function destroy($email)
    {
         DB::delete('delete from officestaffs where email = ?',[$email]);
		 DB::delete('delete from logins where username = ?',[$email]);
      return redirect('/manage_staff')->with('success','Student has been deleted');
    }
}
