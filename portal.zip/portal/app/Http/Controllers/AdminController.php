<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Register;
use App\duty;

class AdminController extends Controller
{
   public function addstudent()
   {
	   //return view('admin.Register');
	   $countries = DB::table("countries")->pluck("name","id");
	    $departments = DB::table("departments")->pluck("name","id");
        return view('admin.Register',compact('countries','departments'));
    }

    public function getStateList(Request $request)
    {
        $states = DB::table("states")
        ->where("country_id",$request->country_id)
        ->pluck("name","id");
        return response()->json($states);
    }

    public function getCityList(Request $request)
    {
        $cities = DB::table("cities")
        ->where("state_id",$request->state_id)
        ->pluck("name","id");
        return response()->json($cities);
    }
	 public function getCourseList(Request $request)
    {
        $courses = DB::table("courses")
        ->where("dept_id",$request->dept_id)
        ->pluck("name","id");
        return response()->json($courses);
    }
    public function getSemList(Request $request)
    {
        $semesters = DB::table("semesters")
        ->where("course_id",$request->course_id)
        ->pluck("name","id");
        return response()->json($semesters);
    }
   
     public function addteacher()
   {
	   $countries = DB::table("countries")->pluck("name","id");
        $departments = DB::table("departments")->pluck("name","id");
        $duties = duty::all();
        return view('admin.Teacher',compact('countries','departments','duties'));
	   //return view('admin.Teacher');
   }
    public function getStateListt(Request $request)
    {
        $states = DB::table("states")
        ->where("country_id",$request->country_id)
        ->pluck("name","id");
        return response()->json($states);
    }

    public function getCityListt(Request $request)
    {
        $cities = DB::table("cities")
        ->where("state_id",$request->state_id)
        ->pluck("name","id");
        return response()->json($cities);
    }
    public function addstaff()
   {
	   $countries = DB::table("countries")->pluck("name","id");
	    $departments = DB::table("departments")->pluck("name","id");
        return view('admin.Officestaff',compact('countries','departments'));
	  // return view('admin.Officestaff');
   }
   public function getStateListos(Request $request)
    {
        $states = DB::table("states")
        ->where("country_id",$request->country_id)
        ->pluck("name","id");
        return response()->json($states);
    }

    public function getCityListos(Request $request)
    {
        $cities = DB::table("cities")
        ->where("state_id",$request->state_id)
        ->pluck("name","id");
        return response()->json($cities);
    }
   
   
   
   public function addparent()
   {
	   $countries = DB::table("countries")->pluck("name","id");
        $departments = DB::table("departments")->pluck("name","id");
        $user=Register::all();
        return view('admin.Parent',compact('countries','departments','user'));
	  
	   //return view('admin.Parent');
   }
    public function getStateListp(Request $request)
    {
        $states = DB::table("states")
        ->where("country_id",$request->country_id)
        ->pluck("name","id");
        return response()->json($states);
    }

    public function getCityListp(Request $request)
    {
        $cities = DB::table("cities")
        ->where("state_id",$request->state_id)
        ->pluck("name","id");
        return response()->json($cities);
    }
    public function dept()
    {
        return view('admin.add-department');
    }

}
