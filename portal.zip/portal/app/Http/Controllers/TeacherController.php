<?php

namespace App\Http\Controllers;

use App\Teacher;
use Illuminate\Http\Request;
use DB;
use Crypt;
use Hash;
use Mail;
use App\Mail\SendEmail;
use App\Register;
use App\Login;
class TeacherController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function count2(Register $register, Request $request)
    {
       $check=DB::table('select * from registers');
       $username=$request->session()->get('email');
       $users=DB::table('teachers')->where(['email'=>$username])->get();
    //    $arcs=DB::table('arcticians')->where(['email'=>$username])->get();
    //    $items=DB::table('accounts')->where(['user_name'=>$username])->get();
    //    $hotels=DB::table('hotels')->get();
       //return view('User.service',compact('items','hotels','users','arcs'));
       $reg = Register::count();
       //$users = Faculty::paginate(5);
    //    $arc=count(DB::table('faculties')->get());
    //    $dep=Department::count();
    //    $cou=Course::count();
    
	   
       return view('faculty.home',compact('reg','users'));
       //return view('faculty.home',compact('reg'));
    }
	  public function view(Request $request)
    {
		//$unm = $request->session()->get('username');
		//$users=Register::all();
		 $users = Teacher::paginate(5);
		//$users = DB::select('select * from registers')->get();
		 //$users=DB::table('registers')->where(['email'=>$unm])->get();
      return view('admin.manage_teacher',compact('users'));
	
		//$items = DB::table('registers')->get();
		//return view('admin.manage_student',compact('students'));
	}
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
		$filename6=$request->img1->getClientOriginalName();
		$request->img1->storeAs('public/upload',$filename6);
 
         $uname=$request->input('mail');
		//$msg="";
		 $check=DB::table('teachers')->where(['email'=>$uname])->get();
		 if(count($check)==0)
		
		{
                      $users=new Teacher([
					  // 'reg_no'=>$request->get('regno'),
						 'fname'=>$request->get('firstname'),
						 'lname'=>$request->get('lastname'),
	                     'dob'=>$request->get('dob'),
						 'gender'=>$request->get('gender'),
						 'dept'=>$request->get('dept'),
						 'qualification'=>$request->get('qualification'),
						 'join_date'=>$request->get('joindate'),
						 'house_name'=>$request->get('house'),
						 'place'=>$request->get('place'),
						 'country'=>$request->get('country'),
						 'state'=>$request->get('state'),
						 'district'=>$request->get('district'),
						
						 'mobile'=>$request->get('mobileno'),
						 'email'=>$request->get('mail'),
						 
	                     'duty'=>$request->get('duty'),
	                    
						 'image'=>$filename6,
						// 'username'=>$request->get('username'),
						 //'password'=>$request->get('password'),
						 //'image'=>$request->get('imageico'),
						 'status'=>1
	                  ]);
					  $users->save();
					  $name=$request->input('firstname');
					   $hpwd = Hash::make($request->input('password'));
					  $pwd=$request->input('password');
					  //$conpwd=$request->input('conpassword');
					 
					 // if ($pwd==$conpwd)
		             //{             
					     $result=DB::insert("insert into logins(email,password,fname,role,status)values(?,?,?,?,?)",[$uname,$hpwd,$name,3,1]);
					    // return view('admin.home');
                        //return redirect()->back()->with('success','successfully added');
                        $email=$uname;
						$subject="New registration";
                   $message="Now You are the part of the Institution 
                   Your username is :".$email."
                        <br>
                   password is :".$pwd;
                           Mail::to($email)->send(new SendEmail($subject,$message));					 
                   // return redirect('/')->with('alert', 'Now You are the part of Guruvayoor Devout Cabinet, check your mail for more details');


                   return redirect()->back()->with('success', 'Teacher Added and Sent Email too');

					 
		             //}  
                     //else
                     //{
						//$msg= "not match";
						 //return view('welcome');
					 //}	
					 	
		}	
		else
		{
			         //    $msg= "User Already Registered";
						 
						return redirect('/already');
		}	
             //return view('/add_stude
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Teacher  $teacher
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Teacher  $teacher
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $teacher=Teacher::find($id);
	 return view('admin.edit',compact('teacher'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Teacher  $teacher
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
       
         $teacher=Teacher::find($id);
	   //$faculty->firstname=$request->get('firstname');
	   //$faculty->lastname=$request->get('lastname');
		$teacher->qualification=$request->get('qualification');
		$teacher->house_name=$request->get('house');
		$teacher->mobile=$request->get('mobile');
		
		
		//$faculty->qualification=$request->get('qualification');
		
		$teacher->email=$request->get('email');
	  
	 
	   $teacher->save();
	   return redirect('/manage');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Teacher  $teacher
     * @return \Illuminate\Http\Response
     */
    public function destroy($email)
    {
       DB::delete('delete from teachers where email = ?',[$email]);
		 DB::delete('delete from logins where email = ?',[$email]);
      return redirect('/manage')->with('success','teacher has been deleted');
    }
}
