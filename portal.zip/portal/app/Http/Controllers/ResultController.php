<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Register;
class ResultController extends Controller
{
    public function view1(Request $request)
    {
        $unm = $request->session()->get('email');
        $nm = $request->session()->get('stud_name');
		
		//$check=DB::table('registers')->where(['email'=>$unm])->get();
        $data = DB::table('registers')->where(['email'=>$unm])->get();
        $users = Register::paginate(5);
        return view('student.result',compact('data','users'));
    }
    public function show()
    {
        
    }
}
