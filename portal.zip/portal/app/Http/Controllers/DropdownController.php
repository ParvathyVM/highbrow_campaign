<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;

class DropdownController extends Controller
{
	
    public function index2(Request $request)
    {
        $unm = $request->session()->get('email');
        $unames=DB::table('registers')->select('department')
        ->where(['email'=>$unm])->first();
        $dept=$unames->department;
      // print_r($unames);
        $unames1=DB::table('registers')->select('stream')
        ->where(['email'=>$unm])->first();
        $course=$unames1->stream;
        //print_r($unames1);
        $unames2=DB::table('registers')->select('semester')
        ->where(['email'=>$unm])->first();
        $sem=$unames2->semester;
        //print_r($unames2);
		//$check=DB::table('registers')->where(['email'=>$unm])->get();
        $data = DB::table('registers')->where(['email'=>$unm])->get();
        $users=DB::table('questionuploads')->where(['dept'=>$dept,'course'=>$course,'sem'=>$sem])->get();
        //print_r($users);
        $departments = DB::table("departments")->where('status','active')->pluck("name","id");
        return view('students.showresult',compact('data','departments','users'));
    }
    public function download_file(){
        return Response::download(public_path() . "/files/file_1.txt");
    }
    public function index3(Request $request)
    {
        $unm = $request->session()->get('email');
        $unames=DB::table('registers')->select('department')
        ->where(['email'=>$unm])->first();
        $dept=$unames->department;
      // print_r($unames);
        $unames1=DB::table('registers')->select('stream')
        ->where(['email'=>$unm])->first();
        $course=$unames1->stream;
        //print_r($unames1);
        $unames2=DB::table('registers')->select('semester')
        ->where(['email'=>$unm])->first();
        $sem=$unames2->semester;
        //print_r($unames2);
		//$check=DB::table('registers')->where(['email'=>$unm])->get();
        $data = DB::table('registers')->where(['email'=>$unm])->get();
        $users=DB::table('notes')->where(['dept'=>$dept,'course'=>$course,'sem'=>$sem])->get();
        //print_r($users);
        $departments = DB::table("departments")->where('status','active')->pluck("name","id");
        
        return view('students.note',compact('data','departments','users'));
    }
    public function indexnoti(Request $request)
    {
        $unm = $request->session()->get('email');
        $unames=DB::table('registers')->select('department')
        ->where(['email'=>$unm])->first();
        $dept=$unames->department;
      // print_r($unames);
        $unames1=DB::table('registers')->select('stream')
        ->where(['email'=>$unm])->first();
        $course=$unames1->stream;
        //print_r($unames1);
        $unames2=DB::table('registers')->select('semester')
        ->where(['email'=>$unm])->first();
        $sem=$unames2->semester;
        //print_r($unames2);
		//$check=DB::table('registers')->where(['email'=>$unm])->get();
        $data = DB::table('registers')->where(['email'=>$unm])->get();
        $users=DB::table('notifications')->where(['dept'=>$dept,'course'=>$course,'sem'=>$sem])->get();
        //print_r($users);
        $departments = DB::table("departments")->where('status','active')->pluck("name","id");
        
        return view('students.shownoti',compact('data','departments','users'));
    }
    public function indexevent(Request $request)
    {
        $unm = $request->session()->get('email');
        $unames=DB::table('registers')->select('department')
        ->where(['email'=>$unm])->first();
        $dept=$unames->department;
      // print_r($unames);
        $unames1=DB::table('registers')->select('stream')
        ->where(['email'=>$unm])->first();
        $course=$unames1->stream;
        //print_r($unames1);
        $unames2=DB::table('registers')->select('semester')
        ->where(['email'=>$unm])->first();
        $sem=$unames2->semester;
        //print_r($unames2);
		//$check=DB::table('registers')->where(['email'=>$unm])->get();
        $data = DB::table('registers')->where(['email'=>$unm])->get();
        $users=DB::table('events')->where(['dept'=>$dept,'course'=>$course,'sem'=>$sem])->get();
        //print_r($users);
        $departments = DB::table("departments")->where('status','active')->pluck("name","id");
        
        return view('students.showevent',compact('data','departments','users'));
    }
    public function indexquest(Request $request)
    {
        $unm = $request->session()->get('email');
        $unames=DB::table('registers')->select('department')
        ->where(['email'=>$unm])->first();
        $dept=$unames->department;
      // print_r($unames);
        $unames1=DB::table('registers')->select('stream')
        ->where(['email'=>$unm])->first();
        $course=$unames1->stream;
        //print_r($unames1);
        $unames2=DB::table('registers')->select('semester')
        ->where(['email'=>$unm])->first();
        $sem=$unames2->semester;
        //print_r($unames2);
		//$check=DB::table('registers')->where(['email'=>$unm])->get();
        $data = DB::table('registers')->where(['email'=>$unm])->get();
        $users=DB::table('questionuploads')->where(['dept'=>$dept,'course'=>$course,'sem'=>$sem])->get();
        //print_r($users);
        $departments = DB::table("departments")->where('status','active')->pluck("name","id");
        
        return view('students.showquest',compact('data','departments','users'));
    }
}