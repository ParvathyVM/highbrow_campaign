<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use DB;
class PayController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     * 
     */
    public function index()
    {
        //
    }
    public function view(Request $request)
    {
        $username=$request->session()->get('email');
        $fee=25000;
        return view('parents.auc_payment',compact('fee','username'));
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $getid=session()->get('email');

       
        $email= $request->get('email');
        $students=DB::table('parents')->select('student')->where('email',$email)->first();
        $stname=$students->student;
        $stud=DB::table('parents')->select('adm_no')->where('email',$email)->first();
        $stno=$stud->adm_no;
       $cardname= $request->get('cardname');
       $cardNumber= $request->get('cardnumber');
       $months= $request->get('exp_month');
       $year= $request->get('exp_year');
       $cardCVV= $request->get('cvv');
       $amount= $request->get('fee');


        $b=DB::table('bank')
       ->where('user_name' ,'=', $cardname)
        ->where('card_num', '=', $cardNumber)
        ->where('exp_month', '=', $months)
       ->where('exp_year', '=', $year)
       ->where('card_cvv', '=', $cardCVV)
       ->get();
        

       if(count($b) == 0)
       {
            return redirect()->back()->with('message','incorrect');;
       }
       else{

        $amount1=DB::select('select balance from bank where card_num = ?',[$cardNumber]);
        $amount2=DB::select('select balance from bank where card_num = ?',['2000200120022003']);
        //return $amount2;
        // $note_id=DB::select('select note_id from notes where ');

        if($amount1[0]->balance > $amount){
            $rem=$amount1[0]->balance-$amount;
        $adminbalance=$amount2[0]->balance+$amount;
        DB::update('update bank set balance = ? where card_num = ?',[$rem,$cardNumber]);
        DB::update('update bank set balance = ? where card_num = ?',[$adminbalance,'2000200120022003']);
       // return $request->get('note')
       //return $pay;
$date=date('Y-m-d');
       $result=DB::insert("insert into feepayment(adm_no,student,amount,date)values(?,?,?,?)",[$stno,$stname,$amount,$date]);
       DB::update('update registers set payment = 0 where id = ?',[$stno]);
       //return $nn;
       //return redirect('/downloadnote',compact('nn'));

        return view('parents.slip',compact('amount','stname','stno'));

        }
        else
        {
            return redirect()->back()->with('message','no balance');

        }
       }


       return redirect('/notedownload');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request)
    {
        $username=$request->session()->get('email');
        $data=DB::table('officestaffs')->where(['email'=>$username])->get();
       
        $studs=DB::select('select * from feepayment');
        return view('staff.payview',compact('studs','data'));
    }
public function due(Request $request)
{
    $username=$request->session()->get('email');
        // $data=DB::table('officestaffs')->where(['email'=>$username])->get();
        $data=DB::table('officestaffs')->where(['email'=>$username])->get();
        // $studs=DB::select('select * from registers');
        $data1=DB::table('registers')->where(['payment'=>0])->get();
               
        return view('staff.due',compact('data1','data'));
}
    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
