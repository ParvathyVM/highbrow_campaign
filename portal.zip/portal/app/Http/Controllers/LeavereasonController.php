<?php

namespace App\Http\Controllers;

use App\Leavereason;
use Illuminate\Http\Request;
use DB;
use Mail;
use App\Mail\SendEmail;

class LeavereasonController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $unm = $request->session()->get('email');
		
		//$check=DB::table('registers')->where(['email'=>$unm])->get();
        $data = DB::table('registers')->where(['email'=>$unm])->get();
        //$datas = DB::table('invigilators')->where(['email'=>$unm])->paginate(5);
        return view('students.leavereason',compact('data'));
    }
    public function view(Request $request)
    {
       
		
		//$check=DB::table('registers')->where(['email'=>$unm])->get();
        //$users = DB::table('teachers')->where(['email'=>$unm])->get();
        //$datas = DB::table('invigilators')->where(['email'=>$unm])->paginate(5);
        //$unm = $request->session()->get('email');
		
        $data =Leavereason::paginate(5);
        $details = DB::table("registers")->where('status',1)->pluck("fname","lname","id");
       
        return view('admin.approval',compact('users','details','data'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function view2(Request $request)
    {
        $unm = $request->session()->get('email');
		
		//$check=DB::table('registers')->where(['email'=>$unm])->get();
        $data = DB::table('registers')->where(['email'=>$unm])->get();
       
        $users=DB::table('leavereasons')->where(['email'=>$unm])->get();
        return view('students.leavestatus',compact('data','users'));
    }
    public function store(Request $request)
    {
        $unm = $request->session()->get('email');
        $unames=DB::table('registers')->select(DB::raw("CONCAT (fname,' ',lname) as fullname"))
        ->orderBy('lname','ASC')
        ->where(['email'=>$unm])->first();
        $leave=new Leavereason([
            'email'=>$request->get('email'),
            'date'=>$request->get('date'),
            'reason'=>$request->get('desc'),
            'status'=>"Not approved",
        ]);
        $leave->save();
        
        $email1= DB::table('parents')
        ->join('registers','registers.id','=','parents.adm_no')
        ->select('parents.email')->get();
$uname=$unames->fullname;
        $email=$email1;
        $subject="Leave Applied";
   $message="Applied for leave By".$uname;
   
           Mail::to($email)->send(new SendEmail($subject,$message));					 
  
   return redirect()->back()->with('success', 'Leave Applied');
     
       // return redirect()->back()->with('success', 'Leave Applied ');
    }
    public function store1(Request $request)
    {
        $leave=new Leavereason([
            'email'=>$request->get('email'),
            'date'=>$request->get('date'),
            'reason'=>$request->get('desc'),
        ]);
        $leave->save();
        return redirect()->back()->with('success', 'Leave Applied ');
    }
    /**
     * Display the specified resource.
     *
     * @param  \App\Leavereason  $leavereason
     * @return \Illuminate\Http\Response
     */
    public function show(Leavereason $leavereason)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Leavereason  $leavereason
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $data = Leavereason::where('id', $id)->get();
        $user= Leavereason::where('id', $id)->update(['status'=> 'Approved']);
              
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Leavereason  $leavereason
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Leavereason $leavereason)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Leavereason  $leavereason
     * @return \Illuminate\Http\Response
     */
    public function destroy(Leavereason $leavereason)
    {
        //
    }
    public function des($id)
    {
        // DB::table('courses')->where('id',$id)->update(array(
            //             'status'=>'inactive',)); 
            
            // return redirect('/edit-course');
            $data = Leavereason::where('id', $id)->get();
                    //$log = Login::find($loginid);
                    foreach($data as $obj){
                     if($obj -> status == 'Not Approved'){
                            Leavereason::where('id', $id)->update(['status'=> 'Approved']);
                           //  $user = Departemnt::where('id', $id)->select('uname')->get();
                           //  Register::where('uname', $user[0]->uname)->update(['ustatus'=> 2]);
                        }
                        else if($obj -> status == 'Approved'){
            
                          Leavereason::where('id',$id)->update(['status'=> 'Not Approved']);
                           // $user = Login::where('loginid', $loginid)->select('uname')->get();
                           // Register::where('uname', $user[0]->uname)->update(['ustatus'=> 1]);
            
                        }
            //         DB::table('departments')->where('id',$id)->update(array(
            //             'status'=>'inactive',)); 
            
             return redirect('/approval');
            }
    }
}
