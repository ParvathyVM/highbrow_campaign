<?php

namespace App\Http\Controllers;

use App\Apptitudes;
use Illuminate\Http\Request;
use DB;
use App\Subject;

class ApptitudesController extends Controller
{
    public function view(Request $request)
    {
        $unm = $request->session()->get('email');
		
        $dept=$request->get('dept');
		$users = DB::table('teachers')->where(['email'=>$unm])->get();
        $departments = DB::table("departments")->where('status','active')->pluck("name","id");
        //$subjects = DB::table("subjects")->pluck("sub_name","sub_id");
        $subjects=Subject::all();
		return view('classteacher.apptitudes',compact('users','departments','subjects'));
    }

    public function view3(Request $request)
    {
        $unm = $request->session()->get('email');
		
        $dept=$request->get('dept');
		$users = DB::table('teachers')->where(['email'=>$unm])->get();
        $departments = DB::table("departments")->where('status','active')->pluck("name","id");
        //$subjects = DB::table("subjects")->pluck("sub_name","sub_id");
        $subjects=Subject::all();
		return view('faculty.apptitudes',compact('users','departments','subjects'));
    }

    public function view2(Request $request)
    {
        
		
        $dept=$request->get('dept');
		$users=apptitudes::paginate(5);
        $departments = DB::table("departments")->where('status','active')->pluck("name","id");
        //$subjects = DB::table("subjects")->pluck("sub_name","sub_id");
        
		return view('admin.viewquest',compact('users','departments'));
    }
    public function index(Request $request)
    {
        $unm = $request->session()->get('email');
		
        //$dept=$request->get('dept');
		$users = DB::table('teachers')->where(['email'=>$unm])->get();
        $departments = DB::table("departments")->where('status','active')->pluck("name","id");
        //$subjects = DB::table("subjects")->pluck("sub_name","sub_id");
        $subjects=Subject::all();
		return view('faculty.questionset',compact('users','departments','subjects'));
    }
    public function getCourseList(Request $request)
    {
        $courses = DB::table("courses")
        ->where("dept_id",$request->dept_id)->where("status",'active')
        ->pluck("name","id");
        return response()->json($courses);
    }
    public function getStreamList(Request $request)
    {
        $streams= DB::table("semesters")
        ->where("course_id",$request->course_id)
        ->pluck("name","id");
        return response()->json($streams);
    }
    public function getSubjectList(Request $request)
    {
        $subjects = DB::table("subjects")
        ->where("semester_id",$request->semester_id)
        ->pluck("sub_name","sub_id");
        return response()->json($subjects);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        $unm = $request->session()->get('email');
		
        //$dept=$request->get('dept');
		$data = DB::table('teachers')->where(['email'=>$unm])->get();
        //$departments = DB::table("departments")->where('status','active')->pluck("name","id");
        //$subjects = DB::table("subjects")->pluck("sub_name","sub_id");
        $data1=apptitudes::paginate(5);
		return view('classteacher.manageset',compact('data','data1'));
    }
    public function create1(Request $request)
    {
        $unm = $request->session()->get('email');
		
        //$dept=$request->get('dept');
		$data = DB::table('teachers')->where(['email'=>$unm])->get();
        //$departments = DB::table("departments")->where('status','active')->pluck("name","id");
        //$subjects = DB::table("subjects")->pluck("sub_name","sub_id");
        $data1=apptitudes::paginate(5);
		return view('faculty.manageset',compact('data','data1'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $sub=new Apptitudes([
            //'sub_code'=>$request->get('code'),
            'sub'=>$request->get('subject'),
            'dept'=>$request->get('dept'),
            'course'=>$request->get('course'),
            'sem'=>$request->get('semester'),
            'dept_id'=>$request->get('dept'),
            'course_id'=>$request->get('course'),
            'semester_id'=>$request->get('semester'),
            //'sub_id'=>$request->get('subject'),
           'question'=>$request->get('quest'),
           'opta'=>$request->get('opta'),
           'optb'=>$request->get('optb'),
           'optc'=>$request->get('optc'),
           'optd'=>$request->get('optd'),
           'answer'=>$request->get('ans'),
           'level'=>$request->get('level'),
        ]);
        $sub->save();

    
        return redirect()->back()->with('success', 'Added Successfully');


    }
    public function store1(Request $request)
    {
        $sub=new apptitudes([
            //'sub_code'=>$request->get('code'),
            'sub_name'=>$request->get('subject'),
            'dept'=>$request->get('dept'),
            'course'=>$request->get('course'),
            'sem'=>$request->get('semester'),
            'dept_id'=>$request->get('dept'),
            'course_id'=>$request->get('course'),
            'semester_id'=>$request->get('semester'),
            'sub_id'=>$request->get('subject'),
           'question'=>$request->get('quest'),
           'level'=>$request->get('level'),
        ]);
        $sub->save();

    
        return redirect()->back()->with('success', 'Added Successfully');


    }
    public function search(Request $request)
    {
        // $unm = $request->session()->get('email');
		
		// //$check=DB::table('registers')->where(['email'=>$unm])->get();
        // $data = DB::table('teachers')->where(['email'=>$unm])->get();
        //$passyear = Input::get ( 'year' );
        $dept = Input::get ( 'department' );
        $course = Input::get ( 'course' );
        $sem = Input::get ( 'semester' );
        $sub = Input::get ( 'subject' );
    $user = apptitudes::Where('dept','LIKE','%'.$dept.'%')->Where('course','LIKE','%'.$course.'%')->Where('sem','LIKE','%'.$sem.'%')->Where('sub_name','LIKE','%'.$sub.'%')->get();
   if(count($user) > 0){
        return view('admin.getresult')->withDetails($user)->withQuery (  $dept, $course, $sem, $sub );

   }

        else 
    return redirect()->back()->with('success', 'Not Found');
        
    }


    /**
     * Display the specified resource.
     *
     * @param  \App\apptitudes  $apptitudes
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $student=apptitudes::find($id);
        return view('faculty.editquest',compact('student'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\apptitudes  $apptitudes
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request,$id)
    {
         $unm = $request->session()->get('email');
		
		// //$check=DB::table('registers')->where(['email'=>$unm])->get();
        $users = DB::table('teachers')->where(['email'=>$unm])->get();
        $students=apptitudes::find($id);
        return view('classteacher.questedit',compact('students','users'));
      
    }
  
    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\apptitudes  $apptitudes
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $students=apptitudes::find($id);
	  
		$students->question=$request->get('question');
        $students->sub_name=$request->get('sub');
        //$students->stream=$request->get('stream');
        $students->level=$request->get('level');
       
	  
	 
	   $students->save();
	   return redirect('/managesetquest');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\apptitudes  $apptitudes
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        DB::delete('delete from apptitudes where id = ?',[$id]);
    return redirect('/managesetquest')->with('success',' Deleted');
    }
public function cre(Request $request,$id)
{



    $students=apptitudes::find($id);
	  
    $students->question=$request->get('question');
    $students->sub_name=$request->get('sub');
    //$students->stream=$request->get('stream');
    $students->level=$request->get('level');
   
  
 
   $students->save();
   return redirect('/managesetquest1');
}
}