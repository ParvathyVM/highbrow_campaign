<?php

namespace App\Http\Controllers;
use DB;
use App\Register;
use App\Uploadmark;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;

class ManagemarkController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function view(Request $request)
    {
        $unm = $request->session()->get('email');
        $users = DB::table('faculties')->where(['email'=>$unm])->get();
        $departments = DB::table("departments")->where('status','active')->pluck("name","id");
        return view('classteacher.uploadmark',compact('users','departments'));
    }



    public function index(Request $request)
    {
        $unm = $request->session()->get('email');
        $users = DB::table('faculties')->where(['email'=>$unm])->get();
        $departments = DB::table("departments")->where('status','active')->pluck("name","id");
        return view('faculty.markmanage',compact('users','departments'));
    }
    public function getCourseList(Request $request)
    {
        $courses = DB::table("courses")
        ->where("dept_id",$request->dept_id)->where("status",'active')
        ->pluck("name","id");
        return response()->json($courses);
    }
    public function getStreamList(Request $request)
    {
        $streams= DB::table("semesters")
        ->where("course_id",$request->course_id)
        ->pluck("name","id");
        return response()->json($streams);
    }
    public function getSubjectList(Request $request)
    {
        $subjects = DB::table("subjects")
        ->where("semester_id",$request->semester_id)
        ->pluck("sub_name","sub_id");
        return response()->json($subjects);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request, $id)
    {
        $unm = $request->session()->get('email');
        $users = DB::table('faculties')->where(['email'=>$unm])->get();
        $students=Uploadmark::find($id);
	 return view('faculty.editmark',compact('users','students'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $students=Uploadmark::find($id);
        //$students->firstname=$request->get('firstname');
        //$students->lastname=$request->get('lastname');
         $students->stud_id=$request->get('reg');
         $students->stud_name=$request->get('name');
         $students->typeexam=$request->get('type');
         $students->sub_name=$request->get('sub');
        // $students->stream=$request->get('stream');
         $students->marks=$request->get('marks');
         $students->total=$request->get('total');
        //  $students->email=$request->get('email');
        // $students->course=$request->get('course');
      
        $students->save();
        return redirect('/managemark');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
    public function seaa(Request $request)
    {
        $unm = $request->session()->get('email');
		
		//$check=DB::table('registers')->where(['email'=>$unm])->get();
        $data = DB::table('faculties')->where(['email'=>$unm])->get();
        //$datas = DB::table('allocations')->select('sub_name')->where(['email'=>$unm])->get();
        //$passyear = Input::get ( 'year' );
        $dept = Input::get ( 'dept' );
        $course = Input::get ( 'course' );
        $sem = Input::get ( 'semester' );
    $user = Uploadmark::Where('dept','LIKE','%'.$dept.'%')->Where('course','LIKE','%'.$course.'%')->Where('sem','LIKE','%'.$sem.'%')->limit(10)->get();
   if(count($user) > 0){
        return view('faculty.managemark',compact('data','datas'))->withDetails($user)->withQuery (  $dept, $course, $sem );

   }

        else 
    return redirect()->back()->with('success', 'Not Found');
        
    }


}

