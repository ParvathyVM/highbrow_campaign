<?php

namespace App\Http\Controllers;
use DB;
use Illuminate\Http\Request;
use App\Subject;
use View;
use Illuminate\Support\Facades\Input;
class ExamresultController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $unm = $request->session()->get('email');
        
        $data = DB::table('registers')->where(['email'=>$unm])->get();
        
        $unames=DB::table('registers')->select('department')
        ->where(['email'=>$unm])->first();
        $dept=$unames->department;
        //print_r($unames);
        $unames1=DB::table('registers')->select('stream')
        ->where(['email'=>$unm])->first();
        $course=$unames1->stream;
        //print_r($unames1);
        $unames2=DB::table('registers')->select('semester')
        ->where(['email'=>$unm])->first();
        $sem=$unames2->semester;
        //print_r($unames2);
        $subs = Subject::where(['dept'=>$dept,'course'=>$course,'sem'=>$sem])->get();
        $types = DB::table('examtype')->select('type')->pluck('type');
        $users=DB::table('marks')->where(['email'=>$unm,'dept'=>$dept,'course'=>$course,'sem'=>$sem])->get();
        //$departments = DB::table("departments")->where('status','active')->pluck("name","id");
        return view('students.showresult',compact('types','users','departments','subs','types'));
    }
    public function seas1(Request $request)
    {
        $unm = $request->session()->get('email');
        
        $data = DB::table('registers')->where(['email'=>$unm])->get();
        
        $unames=DB::table('registers')->select('department')
        ->where(['email'=>$unm])->first();
        $dept=$unames->department;
        //print_r($unames);
        $unames1=DB::table('registers')->select('stream')
        ->where(['email'=>$unm])->first();
        $course=$unames1->stream;
        //print_r($unames1);
        $unames2=DB::table('registers')->select('semester')
        ->where(['email'=>$unm])->first();
        $sem=$unames2->semester;
        
        $types = DB::table('examtype')->select('type')->pluck('type');
        $users=DB::table('marks')->where(['email'=>$unm,'dept'=>$dept,'course'=>$course,'sem'=>$sem])->get();
        $sub = Input::get ( 'type' );
  //  $subs = DB::table('sub_name')->where(['email'=>$unm])->get();

    $users=DB::table('marks')->where(['email'=>$unm,'dept'=>$dept,'course'=>$course,'sem'=>$sem,'typeexam'=>$sub])->get();

   if(count($users) > 0){
        return View::make('students.result',compact('data','users','departments','subs','types'))->withDetails($users)->withQuery (  $dept, $course, $sem,$sub );

   }

        else 
    return redirect()->back()->with('success', 'Not Found');
        
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }
    public function parentshow(Request $request)
    {
        $unm = $request->session()->get('email');
        $data=DB::table('parents')->where(['email'=>$unm])->get();
        $data1=DB::table('marks')
               ->join('parents','marks.stud_id','=','parents.adm_no')
               ->select('marks.stud_id','marks.stud_name','marks.typeexam','marks.sub_name','marks.marks','marks.total')
               ->where('parents.email',$unm)
               ->get();
               return view('parents.studresult',compact('data1','data'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
