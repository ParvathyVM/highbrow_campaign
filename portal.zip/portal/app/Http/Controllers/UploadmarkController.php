<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Register;
use DB;
use App\Uploadmark;
use Illuminate\Support\Facades\Input;
class UploadmarkController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function view(Request $request)
    {
        $unm = $request->session()->get('email');
        $users = DB::table('teachers')->where(['email'=>$unm])->get();
        $departments = DB::table("departments")->where('status','active')->pluck("name","id");
        return view('classteacher.uploadmark',compact('users','departments'));
    }



    public function index(Request $request)
    {
        $unm = $request->session()->get('email');
        $users = DB::table('teachers')->where(['email'=>$unm])->get();
        $departments = DB::table("departments")->where('status','active')->pluck("name","id");
        $types = DB::table('examtype')->select('type')->get();
        $allocations = DB::table('allocations')->select('sub_name')->where(['email'=>$unm])->get();
        return view('faculty.uploadmark',compact('users','departments','types','allocations'));
    }
    public function getCourseList(Request $request)
    {
        $courses = DB::table("courses")
        ->where("dept_id",$request->dept_id)->where("status",'active')
        ->pluck("name","id");
        return response()->json($courses);
    }
    public function getStreamList(Request $request)
    {
        $streams= DB::table("semesters")
        ->where("course_id",$request->course_id)
        ->pluck("name","id");
        return response()->json($streams);
    }
    public function getSubjectList(Request $request)
    {
        $subjects = DB::table("subjects")
        ->where("semester_id",$request->semester_id)
        ->pluck("sub_name","sub_id");
        return response()->json($subjects);
    }


    public function search(Request $request)
    {
        $unm = $request->session()->get('email');
		
		//$check=DB::table('registers')->where(['email'=>$unm])->get();
        $data = DB::table('teachers')->where(['email'=>$unm])->get();
        //$passyear = Input::get ( 'year' );
        $dept = Input::get ( 'dept' );
        $course = Input::get ( 'course' );
        $sem = Input::get ( 'semester' );
        $subject =  Input::get ( 'subject' );;
        // print_r($subject);
 
         $type =  Input::get ( 'type' );;
    $user = Register::Where('dept','LIKE','%'.$dept.'%')->Where('course','LIKE','%'.$course.'%')->Where('sem','LIKE','%'.$sem.'%')->limit(10)->get();
   if(count($user) > 0){
        return view('faculty.searchget',compact('data','subject','type'))->withDetails($user)->withQuery (  $dept, $course, $sem );

   }

        else 
    return redirect()->back()->with('success', 'Not Found');
        
    }



    public function sea(Request $request)
    {
        $unm = $request->session()->get('email');
		
		//$check=DB::table('registers')->where(['email'=>$unm])->get();
        $data = DB::table('teachers')->where(['email'=>$unm])->get();
        $datas = DB::table('allocations')->select('sub_name')->where(['email'=>$unm])->get();
        //$passyear = Input::get ( 'year' );
        $dept = Input::get ( 'dept' );
        $course = Input::get ( 'course' );
        $sem = Input::get ( 'semester' );
        $subject =  Input::get ( 'subject' );
        // print_r($subject);
 
         $type =  Input::get ( 'type' );
    $user = Register::Where('department','LIKE','%'.$dept.'%')->Where('stream','LIKE','%'.$course.'%')->Where('semester','LIKE','%'.$sem.'%')->limit(10)->get();
   if(count($user) > 0){
        return view('faculty.search',compact('data','datas','subject','type'))->withDetails($user)->withQuery (  $dept, $course, $sem );

   }

        else 
    return redirect()->back()->with('success', 'Not Found');
        
    }

    

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $input = Input::all();
        $condition = $input['name'];
        foreach ($condition as $key => $condition) {
            $student = new Uploadmark;
            $student->stud_id = $input['id'][$key];
            $student->email = $input['email'][$key];
            $student->stud_name = $input['name'][$key];
            $student->dept = $input['dept'][$key];
            $student->course = $input['course'][$key];
            $student->sem = $input['sem'][$key];
            $student->typeexam = $input['type'][$key];
            $student->sub_name = $input['sub'][$key];
            $student->marks = $input['marks'][$key];
            $student->total = $input['total'][$key];
            $student->dept_id = $input['dept'][$key];
            $student->course_id = $input['course'][$key];
            $student->semester_id = $input['sem'][$key];
            $student->save();
        }
    return redirect('/uploadmark');
        }
    
        public function view5(Request $request)
        {
            $unm = $request->session()->get('email');
            $unames=DB::table('registers')->select('department')
            ->where(['email'=>$unm])->first();
            $dept=$unames->department;
          // print_r($unames);
            $unames1=DB::table('registers')->select('stream')
            ->where(['email'=>$unm])->first();
            $course=$unames1->stream;
            //print_r($unames1);
            $unames2=DB::table('registers')->select('semester')
            ->where(['email'=>$unm])->first();
            $sem=$unames2->semester;
            //print_r($unames2);
            //$check=DB::table('registers')->where(['email'=>$unm])->get();
            $data = DB::table('registers')->where(['email'=>$unm])->get();
            $users=DB::table('marks')->where(['dept'=>$dept,'course'=>$course,'sem'=>$sem])->get();
            //print_r($users);
            $departments = DB::table("examtype")->pluck("name","id");
            
            return view('students.viewmark',compact('data','departments','users'));
        }
    

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
