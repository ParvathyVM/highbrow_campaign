<?php

namespace App\Http\Controllers;

use App\Register;
use App\Teacher;
use App\Officestaff;
use App\Parents;
use Illuminate\Http\Request;
use DB;
use Crypt;
use Department;
use Course;
use Semester;
use Hash;
use App\Mail\SendEmail;
use Mail;
use App\Login;
class RegisterController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
	 public function view(Request $request)
    {
		 $users = Register::paginate(5);
         $data=DB::table('registers')
        ->join('departments','registers.department','=','departments.id')
        ->select('departments.name as dname','registers.fname','registers.lname','registers.house_name','registers.mobile','registers.image','registers.email','registers.reg_no','registers.id')
        ->get();
        $sem=DB::table('semesters')
        ->join('registers','registers.semester','=','semesters.id')
        ->select('semesters.name')
        ->get();
      return view('admin.manage_student',compact('users','data','sem'));
	}
    public function index()
    {
        //
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
			
  $filename6=$request->img1->getClientOriginalName();
		$request->img1->storeAs('public/upload',$filename6);
 
        
        $uname=$request->input('mail');
		//$msg="";
		 $check=DB::table('registers')->where(['email'=>$uname])->get();
		 if(count($check)==0)
		
		{
                      $users=new Register([
					   'reg_no'=>$request->get('regno'),
						 'fname'=>$request->get('firstname'),
						 'lname'=>$request->get('lastname'),
	                     'dob'=>$request->get('dob'),
						 'gender'=>$request->get('gender'),
						 'adm_date'=>$request->get('admdate'),
						 'pass_date'=>$request->get('passdate'),						 
						 'house_name'=>$request->get('house'),
						 'place'=>$request->get('place'),
						 'district'=>$request->get('district'),
						 'state'=>$request->get('state'),
						 'country'=>$request->get('country'),
						 'mobile'=>$request->get('mobileno'),
						 'email'=>$request->get('mail'),
	                     'tenth'=>$request->get('tenth'),
	                     'plus_two'=>$request->get('plustwo'),
						 'degree'=>$request->get('degree'),
						 'department'=>$request->get('department'),
						 'stream'=>$request->get('stream'),
						 'semester'=>$request->get('semester'),
						 'image'=>$filename6,
                         'status'=>1,
                         'payment'=>1
	                  ]);
					  $users->save();
					  $name=$request->input('firstname');
                       $hpwd = Hash::make($request->input('password'));
                       $pwd = $request->input('password');
                       $email= $request->get('email');             
					     $result=DB::insert("insert into logins(email,password,fname,role,status)values(?,?,?,?,?)",[$uname,$hpwd,$name,2,1]);
                        $email=$uname;
						$subject="New registration";
                   $message="Now You are the part of the Institution 
                   Your username is :".$email."
                        <br>
                   password is :". $pwd;
                           Mail::to($email)->send(new SendEmail($subject,$message));					 
                   return redirect()->back()->with('success', 'Student Added and Sent Email too');
						
					 	
		}	
		else
		{						 
						return redirect('/already');
		}	
            				
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Register  $register
     * @return \Illuminate\Http\Response
     */
	  public function count(Register $register, Request $request)
    {
       $check=DB::table('select * from registers');
       $check1=DB::table('select * from teachers');
       $check2=DB::table('select * from officestaffs');
       $check3=DB::table('select * from parents');
	   $stud=Register::count();
       $arc=Teacher::count();
	   $offs=Officestaff::count();
       $par=Parents::count();
       
	   
	   return view('admin.home',compact('stud','arc','offs','par'));
    }
    public function show(Register $register)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Register  $register
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $students=Register::find($id);
	 return view('admin.editstudent',compact('students'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Register  $register
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        
        $students=Register::find($id);
		$students->house_name=$request->get('house_name');
		$students->mobile=$request->get('mobile');
		$students->email=$request->get('email');
	   
	 
	   $students->save();
	   return redirect('/edit');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Register  $register
     * @return \Illuminate\Http\Response
     */
    public function destroy($email)
    {
         DB::delete('delete from registers where email = ?',[$email]);
		 DB::delete('delete from logins where email = ?',[$email]);
      return redirect('/edit')->with('success','Student has been deleted');
    }
}
