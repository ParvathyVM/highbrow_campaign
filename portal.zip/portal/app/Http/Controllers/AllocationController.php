<?php

namespace App\Http\Controllers;

use App\Allocation;
use DB;
use Illuminate\Http\Request;

class AllocationController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function view()
    {
        $teachers =  DB::table('teachers')
        ->select(DB::raw("id,CONCAT(fname,' ',lname) as fullname"))
        ->orderBy('lname','asc')
        ->pluck('fullname','id');
        $departments = DB::table("departments")->where('status','active')->pluck("name","id");
        return view('admin.allocate',compact('teachers','departments'));
        // $departments=Allocation::paginate(5);
        // return view('admin.allocate',compact('departments'));
    }
    public function index()
    {
        
        $teachers =  DB::table('teachers')
        ->select(DB::raw("id,CONCAT(firstname,' ',lastname) as fullname"))
        ->orderBy('lastname','asc')
        ->pluck('fullname','id');
        $departments = DB::table("departments")->where('status','active')->pluck("name","id");
        return view('admin.allocate',compact('teachers','departments'));
    }
    public function getCourseList(Request $request)
    {
        $courses = DB::table("courses")
        ->where("dept_id",$request->dept_id)->where("status",'active')
        ->pluck("name","id");
        return response()->json($courses);
    }
    public function getStreamList(Request $request)
    {
        $streams= DB::table("semesters")
        ->where("course_id",$request->course_id)
        ->pluck("name","id");
        return response()->json($streams);
    }
    public function getSubjectList(Request $request)
    {
        $subjects = DB::table("subjects")
        ->where("semester_id",$request->semester_id)
        ->pluck("sub_name","id");
        return response()->json($subjects);
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $deptid=$request->input('txtbox');
        $sub=new Allocation([
                'duty'=>$request->get('duty'),
                'sub_name'=>$request->get('subject'),
                'dept'=>$request->get('dept'),
                'course'=>$request->get('course'),
                'sem'=>$request->get('sem'),
               //'sub_status'=>$request->get('status'),
               'dept_id'=>$request->get('dept'),
               'course_id'=>$request->get('course'),
               'semester_id'=>$request->get('sem'),
               'teacher_name'=>$request->get('faculty'),
               'class'=>$request->get('class'),
               //'semester_id'=>$request->get('sem'),
            ]);
            $sub->save();

        
            return redirect()->back()->with('success', 'Allocated Successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Allocation  $allocation
     * @return \Illuminate\Http\Response
     */
    public function show(Allocation $allocation)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Allocation  $allocation
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $students=Allocation::find($id);
        return view('admin.edit_allocation',compact('students'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Allocation  $allocation
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $students=Allocation::find($id);
	   //$students->firstname=$request->get('firstname');
	   //$students->lastname=$request->get('lastname');
		$students->teacher_name=$request->get('address');
		//$students->mobile=$request->get('mobile');
		$students->dept=$request->get('dept');
        $students->course=$request->get('course');
        //$students->stream=$request->get('stream');
        $students->sem=$request->get('sem');
        $students->duty=$request->get('year');
		$students->sub_name=$request->get('email');
	   $students->class=$request->get('course1');
	 
	   $students->save();
	   return redirect('/manageallocation');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Allocation  $allocation
     * @return \Illuminate\Http\Response
     */
    public function destroy(Allocation $allocation)
    {
        DB::delete('delete from allocations where id = ?',[$id]);
    return redirect('/manageallocation')->with('success',' deleted');
    }
}
