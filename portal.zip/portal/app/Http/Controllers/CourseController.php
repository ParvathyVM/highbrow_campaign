<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Department;
use App\Course;
class CourseController extends Controller
{
    public function view()
    {
       //$unm = $request->session()->get('username');
       //$users=Register::all();
       $courses = Course::paginate(5);
       //$users = DB::select('select * from registers')->get();
        //$users=DB::table('registers')->where(['email'=>$unm])->get();
     return view('admin.manage-course',compact('courses'));
   
       //$items = DB::table('registers')->get();
       //return view('admin.manage_student',compact('students'));
    }
    public function myform()

{

    // $users= Department::select('name')->get();
    //     return view('admin.add-course',compact('users'));
    
    //$users= Department::select('name')->get();
    $users= Department::all();
        return view('admin.add-course',compact('users'));
}
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //$deptname=$request->input('dept');
        $deptid=$request->input('txtbox');
        $coursename=$request->input('coursename');
        $status=$request->input('status');
        $course=new Course([
                'dept_id'=>$request->get('dept'),
                'name'=>$request->get('coursename'),
               'status'=>$request->get('status'),
            ]);
            $course->save();

        
            return redirect()->back()->with('success', 'Course Inserted Successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Course  $course
     * @return \Illuminate\Http\Response
     */
    public function show(Course $course)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Course  $course
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $course=Course::find($id);
        return view('admin.edit-course',compact('course'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Course  $course
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $course=Course::find($id);
        //$students->firstname=$request->get('firstname');
        //$students->lastname=$request->get('lastname');
         $course->name=$request->get('coursename');
        $course->save();
        return redirect('/edit-course');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Course  $course
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
//         DB::table('courses')->where('id',$id)->update(array(
//             'status'=>'inactive',)); 

// return redirect('/edit-course');
$data = Course::where('id', $id)->get();
        //$log = Login::find($loginid);
        foreach($data as $obj){
            if($obj -> status == 'active'){
                Course::where('id', $id)->update(['status'=> 'Inactive']);
               //  $user = Departemnt::where('id', $id)->select('uname')->get();
               //  Register::where('uname', $user[0]->uname)->update(['ustatus'=> 2]);
            }
            else if($obj -> status == 'Inactive'){

              Course::where('id',$id)->update(['status'=> 'active']);
               // $user = Login::where('loginid', $loginid)->select('uname')->get();
               // Register::where('uname', $user[0]->uname)->update(['ustatus'=> 1]);

            }
//         DB::table('departments')->where('id',$id)->update(array(
//             'status'=>'inactive',)); 

 return redirect('/edit-course');
}
    }
}
