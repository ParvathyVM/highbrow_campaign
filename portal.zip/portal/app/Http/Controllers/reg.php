<html>
<head></head>
<body>
<?php
include("connect.php");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: PUT, GET,POST *");
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept *");
$postdata=file_get_contents("php://input");
$request=json_decode($postdata);
$name=mysqli_real_escape_string($con,trim($request->data->name));
$password=mysqli_real_escape_string($con,trim($request->data->password));
$status=1;
	$sql1="INSERT INTO tbl_angular(`username`,`password`,`status`) VALUES ('$name','$password','$status')";
if(mysqli_query($con,$sql1))
{
	$student=[
	'name'=>$name,
	'password'=>$password,
	'status'=>$status
	];
	echo json_ecode(['data'=>$student]);
}

	?>
