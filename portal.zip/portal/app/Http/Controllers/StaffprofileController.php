<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Officesatff;
class StaffprofileController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function view(staff $register, Request $request)
    {
    
        $username=$request->session()->get('email');
        $users=DB::table('officestaffs')->where(['email'=>$username])->get();
        return view('staff.profile',compact('users'));
    }
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($email)
    {
        $data=Officestaff::find($email);
        return view('staff.editprofile',compact('data'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        $unm = $request->session()->get('email');
		
        $fname=$request->input('u_name');
        $lname=$request->input('l_name');
		$umob=$request->input('mobile');
		$address=$request->input('address');
		$upost=$request->input('post');
		$ucity=$request->input('city');
		$udist=$request->input('district');
        $ustate=$request->input('state');
       
		DB::table('officestaffs')->where('email',$unm)->update(array(
        'fname'=>$fname,'lname'=>$lname,'mobile'=>$umob,'house_name'=>$address,'department'=>$upost,'designation'=>$udist,'qualification'=>$ucity,
)); 
		return redirect('/profile');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function profile_edit(Request $request)
    {
		$unm = $request->session()->get('email');
		
		//$check=DB::table('registers')->where(['email'=>$unm])->get();
		$data = DB::table('officestaffs')->where(['email'=>$unm])->get();
        return view('staff.profile',compact('data'));
    }

    public function haiii(Request $request)
    {
		$unm = $request->session()->get('email');
		
		//$check=DB::table('registers')->where(['email'=>$unm])->get();
		$data = DB::table('officestaffs')->where(['email'=>$unm])->get();
        return view('staff.editprofile',compact('data'));
    }


    public function destroy($id)
    {
        //
    }
}
