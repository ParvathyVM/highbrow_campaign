<?php

namespace App\Http\Controllers;

use App\Event;
use Illuminate\Http\Request;
use DB;
use App\Subject;
use Illuminate\Support\Facades\Validator;
class EventController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function view2(Request $request)
    {
        
        $unm = $request->session()->get('email');
		//$check=DB::table('registers')->where(['email'=>$unm])->get();
		$data = DB::table('teachers')->where(['email'=>$unm])->get();
        //$departments = DB::table("departments")->where('status','active')->pluck("name","id");
        $departments = DB::table("departments")->where('status','active')->pluck("name","id");
		return view('classteacher.event',compact('data','departments'));
    }
    public function index(Request $request)
    {
        $unm = $request->session()->get('email');
		
		//$check=DB::table('registers')->where(['email'=>$unm])->get();
		$data = DB::table('teachers')->where(['email'=>$unm])->get();
        //$departments = DB::table("departments")->where('status','active')->pluck("name","id");
        $departments = DB::table("departments")->where('status','active')->pluck("name","id");
		return view('faculty.event',compact('data','departments'));
    }
    public function getCourseList(Request $request)
    {
        $courses = DB::table("courses")
        ->where("dept_id",$request->dept_id)->where("status",'active')
        ->pluck("name","id");
        return response()->json($courses);
    }
    public function getStreamList(Request $request)
    {
        $streams= DB::table("semesters")
        ->where("course_id",$request->course_id)
        ->pluck("name","id");
        return response()->json($streams);
    }
    public function getSubjectList(Request $request)
    {
        $subjects= DB::table("subjects")
        
        ->pluck("sub_name");
        return response()->json($subjects);
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $input=$request->all();
        $images=array();
        if($files=$request->file('filename')){
            foreach($files as $file){
                $name=$file->getClientOriginalName();
                $file->move('uploads',$name);
                $images[]=$name;
            }
        }
        Event::insert( [
           // 'question_upload'=>  implode("|",$images),
            //'description' =>$input['description'],
            'dept'=>$request->get('dept'),
            'course'=>$request->get('course'),
            'sem'=>$request->get('semester'),
            'event'=>$request->get('desc'),
            //you can put other insertion here
        ]);
             
        
        return redirect()->back()->with('success', 'Uploaded Successfully.');
    
        }
        public function store1(Request $request)
        {
        
        $input=$request->all();
        $images=array();
        if($files=$request->file('filename')){
            foreach($files as $file){
                $name=$file->getClientOriginalName();
                $file->move('uploads',$name);
                $images[]=$name;
            }
        }
        Event::insert( [
            //'question_upload'=>  implode("|",$images),
            //'description' =>$input['description'],
            'dept'=>$request->get('dept'),
            'course'=>$request->get('course'),
            'sem'=>$request->get('semester'),
            'event'=>$request->get('desc'),
            'status'=>1
            
            //you can put other insertion here
        ]);
             
        
    return back()->with('success', 'Your files has been successfully added');
    
        }


        public function view(Request $request)
        {
            $unm = $request->session()->get('email');
            //$check=DB::table('registers')->where(['email'=>$unm])->get();
            $data = DB::table('teachers')->where(['email'=>$unm])->get();
            $datas = Event::paginate(5);
            //$departments = DB::table("departments")->where('status','active')->pluck("name","id");
            //$departments = DB::table("departments")->where('status','active')->pluck("name","id");
            return view('faculty.manaevent',compact('data','datas'));
        }
    /**
     * Display the specified resource.
     *
     * @param  \App\Event  $event
     * @return \Illuminate\Http\Response
     */
    public function show(Event $event)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Event  $event
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request,$id)
    {
        $unm = $request->session()->get('email');
		
		//$check=DB::table('registers')->where(['email'=>$unm])->get();
		$data = DB::table('teachers')->where(['email'=>$unm])->get();
        $students=Event::find($id);
        return view('faculty.editevent',compact('data','students'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\notification  $notification
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request,$id)
    {
        $students=Event::find($id);
        //$students->firstname=$request->get('firstname');
        //$students->lastname=$request->get('lastname');
         $students->event=$request->get('desc');
        
      
        $students->save();
        return redirect('/managevent');
    }
    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Event  $event
     * @return \Illuminate\Http\Response
     */
    public function destroy(Event $event)
    {
        //
    }
}
