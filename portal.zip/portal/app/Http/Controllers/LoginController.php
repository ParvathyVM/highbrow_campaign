<?php

namespace App\Http\Controllers;

use App\Login;
use Illuminate\Http\Request;
use DB;
use Crypt;
use Hash;

class LoginController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        
    }
	public function login(Request $request)
	{
		session_start();
    $email = $request->input('email');
    $pass = $request->input('password');
    $a = Login::where('email',$email)->get();
    if ($a->count() == 0){
        return redirect('/Login')->with('error', 'Wrong username/password');
    }
    foreach ($a as $object)
    {  
	if(!($object->email)){
            return redirect('/Login')->with('error', 'Wrong username/password');
        }
        $id = $object -> id;
        if (($email == $object->email) && (Hash::check($pass,$object->password))){
            session(['email' => $email,
                        'id' => $id]);
            $value = session('email');
            if($object->role == '1'){
               return redirect('/loginme')->with('sess',$value);
            }
            if($object->role == '2'){
                return view('students.studenthome')->with('sess',$value);
            }
            if($object->role == '3'){
                return redirect('/Log')->with('sess',$value);
            }
			 if($object->role == '4'){
                 $data=DB::table('officestaffs')->get();
                return view('staff.staffhome',compact('data'))->with('sess','fname',$value);
            }
			 if($object->role == '5'){
                return view('parents.parenthome')->with('sess',$value);
            }

        }

        else{
            // return "Wrong UserName / Password";
            return redirect('/Login')->with('error', 'Wrong username/password');
        }
    }

    

	}
	

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Login  $login
     * @return \Illuminate\Http\Response
     */
    public function show(Login $login)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Login  $login
     * @return \Illuminate\Http\Response
     */
    public function edit(Login $login)
    {
        //
    }
	public function logout(Request $request)
	{
		session_start();
		$request -> session() ->flush();
		session_destroy();
		return view('/welcome');
	}
	

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Login  $login
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Login $login)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Login  $login
     * @return \Illuminate\Http\Response
     */
    public function destroy(Login $login)
    {
        //
    }
}
