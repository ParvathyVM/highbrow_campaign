<?php

namespace App\Http\Controllers;
use App\Subject;
use Illuminate\Http\Request;
use DB;

class SubjectController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function view()
    {
       
       $subjects = Subject::paginate(5);
      
     return view('admin.manage_subject',compact('subjects'));
   
      
    }


    public function index()
    {
        // $users= Department::all();
        // $user= Course::all();
        $departments = DB::table("departments")->where('status','active')->pluck("name","id");
		return view('admin.subject',compact('departments'));
    }

    public function getCourseList(Request $request)
    {
        $courses = DB::table("courses")
        ->where("dept_id",$request->dept_id)->where("status",'active')
        ->pluck("name","id");
        return response()->json($courses);
    }
    public function getStreamList(Request $request)
    {
        $streams= DB::table("semesters")
        ->where("course_id",$request->course_id)
        ->pluck("name","id");
        return response()->json($streams);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $deptid=$request->input('txtbox');
        $sub=new Subject([
                'sub_code'=>$request->get('subjectcode'),
                'sub_name'=>$request->get('subjectname'),
                'dept'=>$request->get('dept'),
                'course'=>$request->get('course'),
                'sem'=>$request->get('sem'),
               'sub_status'=>$request->get('status'),
               'dept_id'=>$request->get('dept'),
               'course_id'=>$request->get('course'),
               'semester_id'=>$request->get('sem'),
            ]);
            $sub->save();

        
            return redirect()->back()->with('success', 'Subject Inserted Successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Subject  $subject
     * @return \Illuminate\Http\Response
     */
    public function show(Subject $subject)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Subject  $subject
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $course=Subject::find($id);
        return view('admin.edit-subject',compact('course'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Subject  $subject
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request,$id)
    {
        $course=Subject::find($id);
     
         $course->sub_name=$request->get('subjectname');
        $course->save();
        return redirect('/managesub');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Subject  $subject
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
       // DB::table('courses')->where('id',$id)->update(array(
            //             'status'=>'inactive',)); 
            
            // return redirect('/edit-course');
            $data = Subject::where('id', $id)->get();
                    //$log = Login::find($loginid);
                    foreach($data as $obj){
                        if($obj -> sub_status == 'active'){
                            Subject::where('id', $id)->update(['sub_status'=> 'Inactive']);
                           //  $user = Departemnt::where('id', $id)->select('uname')->get();
                           //  Register::where('uname', $user[0]->uname)->update(['ustatus'=> 2]);
                        }
                        else if($obj -> sub_status == 'Inactive'){
            
                          Subject::where('id',$id)->update(['sub_status'=> 'active']);
                           // $user = Login::where('loginid', $loginid)->select('uname')->get();
                           // Register::where('uname', $user[0]->uname)->update(['ustatus'=> 1]);
            
                        }
            //         DB::table('departments')->where('id',$id)->update(array(
            //             'status'=>'inactive',)); 
            
             return redirect('/edit-subject');
            }
                }
    }
