<?php

namespace App\Models;
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Register;
use DB;
use Illuminate\Support\Facades\Input;

class AllStudentsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    

    public function index()
    {
        $departments = DB::table("departments")->where('status','active')->pluck("name","id");
    return view('admin.all_students',compact('departments'));
    }
    public function getCourseList(Request $request)
    {
        $courses = DB::table("courses")
        ->where("dept_id",$request->dept_id)->where("status",'active')
        ->pluck("name","id");
        return response()->json($courses);
    }



    public function search()
    {
        $passyear = Input::get ( 'passyear' );
        $dept = Input::get ( 'department' );
        $course = Input::get ( 'course' );
    $user = Register::where('pass_date','LIKE','%'.$passyear.'%')->Where('department','LIKE','%'.$dept.'%')->Where('stream','LIKE','%'.$course.'%')->get();
    if(count($user) > 0)
        return view('admin.search')->withDetails($user)->withQuery ( $passyear, $dept, $course );
    else 
    return redirect()->back()->with('success', 'Not Found');
    }
    public function datePrice(Request $request){
        $passyear = $request->passyear;
        $department = $request->department;
        $course = $request->course;
    
        $dates = Register::where('pass_date','=',$request->passyear)
        ->where('dept', $request->department)
        ->where('course', $request->course)
        ->get();
        return response()->json($dates);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}

