<?php

namespace App\Http\Controllers;
use App\Faculty;
use DB;

use Illuminate\Http\Request;

class MyProfileController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    // public function view()
    // {
    //    return view('faculty.profile');
    // }
    public function view(Faculty $register, Request $request)
    {
    
        $username=$request->session()->get('email');
       $users=DB::table('teachers')->where(['email'=>$username])->get();
       return view('faculty.profilef',compact('users'));
    }
    // public function index()
    // {
    //     $username=$request->session()->get('email');
    //     $users=DB::table('faculties')->where(['email'=>$username])->get();
    //     return view('faculty.profile',compact('users'));
    // }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($email)
    {
        
    $data=Faculty::find($email);
      return view('faculty.editprofilef',compact('data'));
//     $val=$request->session()->get('email');
//     $data=DB::table('faculties')->where('email',$val) ->get();
//   return view('faculty.editprofile',compact('data'));
    // $unm = $request->session()->get('email');
        
    
	// 	//$check=DB::table('registers')->where(['email'=>$unm])->get();
	// 	$items = DB::table('faculties')->where(['email'=>$unm])->get();
    //     return view('faculty.profile',compact('items'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
    //     $val=$request->session()->get('email');
    //     $data=Faculty::find($email);
    //     $data->firstname=$request->get('firstname');
    //     $data->lastname=$request->get('lastname');
	// 	$data->address=$request->get('address');
	// 	$data->mobile=$request->get('mobile');
	// 	$data->dept=$request->get('dept');
	// 	$data->experience=$request->get('experience');
	// 	$data->email=$request->get('email');
    //     $data->save();
    //    return redirect('/profile');

   
    $unm = $request->session()->get('email');
		
        $fname=$request->input('u_name');
        $lname=$request->input('l_name');
		$umob=$request->input('mobile');
		$address=$request->input('address');
		$upost=$request->input('post');
		$ucity=$request->input('city');
		$udist=$request->input('district');
        $ustate=$request->input('state');
       
		DB::table('teachers')->where('email',$unm)->update(array(
        'fname'=>$fname,'lname'=>$lname,'mobile'=>$umob,'house_name'=>$address,'dept'=>$upost,'qualification'=>$ucity,
)); 
		return redirect('/profilef');
       //return redirect()->back()->with('success', 'Updated Your Profile');
    }

   

    public function profile_edit(Request $request)
    {
		$unm = $request->session()->get('email');
		
		//$check=DB::table('registers')->where(['email'=>$unm])->get();
		$data = DB::table('teachers')->where(['email'=>$unm])->get();
        return view('faculty.profilef',compact('data'));
    }

    public function haiii(Request $request)
    {
		$unm = $request->session()->get('email');
		
		//$check=DB::table('registers')->where(['email'=>$unm])->get();
		$data = DB::table('teachers')->where(['email'=>$unm])->get();
        return view('faculty.editprofilef',compact('data'));
    }


    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
