<?php

namespace App\Http\Controllers;

use App\QuestionUpload;
use Illuminate\Http\Request;
use DB;
use App\Subject;
use Illuminate\Support\Facades\Validator;

class QuestionUploadController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    // public function view(Request $request)
    // {
		
    //     return view('faculty.questionupload',compact('data'));
    // }

    public function view2(Request $request)
    {
        
        $unm = $request->session()->get('email');
		//$check=DB::table('registers')->where(['email'=>$unm])->get();
		$data = DB::table('teachers')->where(['email'=>$unm])->get();
        //$departments = DB::table("departments")->where('status','active')->pluck("name","id");
        $departments = DB::table("departments")->where('status','active')->pluck("name","id");
		return view('classteacher.questionupload',compact('data','departments'));
    }


    public function index(Request $request)
    {
        
        $unm = $request->session()->get('email');
		
		//$check=DB::table('registers')->where(['email'=>$unm])->get();
		$data = DB::table('teachers')->where(['email'=>$unm])->get();
        //$departments = DB::table("departments")->where('status','active')->pluck("name","id");
        $departments = DB::table("departments")->where('status','active')->pluck("name","id");
		return view('faculty.questionupload',compact('data','departments'));
    }

    public function getCourseList(Request $request)
    {
        $courses = DB::table("courses")
        ->where("dept_id",$request->dept_id)->where("status",'active')
        ->pluck("name","id");
        return response()->json($courses);
    }
    public function getStreamList(Request $request)
    {
        $streams= DB::table("semesters")
        ->where("course_id",$request->course_id)
        ->pluck("name","id");
        return response()->json($streams);
    }
    public function getSubjectList(Request $request)
    {
        $subjects= DB::table("subjects")
        
        ->pluck("sub_name");
        return response()->json($subjects);
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
    
    $input=$request->all();
    $images=array();
    if($files=$request->file('filename')){
        foreach($files as $file){
            $name=$file->getClientOriginalName();
            $file->move('uploads',$name);
            $images[]=$name;
        }
    }
    QuestionUpload::insert( [
        'question_upload'=>  implode("|",$images),
        //'description' =>$input['description'],
        'dept'=>$request->get('dept'),
        'course'=>$request->get('course'),
        'sem'=>$request->get('semester'),
        'description'=>$request->get('desc'),
        //you can put other insertion here
    ]);
         
    
    return redirect()->back()->with('success', 'Uploaded Successfully.');

    }
    public function store1(Request $request)
    {
    
    $input=$request->all();
    $images=array();
    if($files=$request->file('filename')){
        foreach($files as $file){
            $name=$file->getClientOriginalName();
            $file->move('uploads',$name);
            $images[]=$name;
        }
    }
    QuestionUpload::insert( [
        'question_upload'=>  implode("|",$images),
        //'description' =>$input['description'],
        'dept'=>$request->get('dept'),
        'course'=>$request->get('course'),
        'sem'=>$request->get('semester'),
        'description'=>$request->get('desc'),
        //you can put other insertion here
    ]);
         
    
return back()->with('success', 'Your files has been successfully added');

    }

    /**
     * Display the specified resource.
     *
     * @param  \App\QuestionUpload  $questionUpload
     * @return \Illuminate\Http\Response
     */
    public function show(QuestionUpload $questionUpload)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\QuestionUpload  $questionUpload
     * @return \Illuminate\Http\Response
     */
    public function edit(QuestionUpload $questionUpload)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\QuestionUpload  $questionUpload
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, QuestionUpload $questionUpload)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\QuestionUpload  $questionUpload
     * @return \Illuminate\Http\Response
     */
    public function destroy(QuestionUpload $questionUpload)
    {
        //
    }
    public function papers()
    {
        return view('students.showquest');
    }
}
