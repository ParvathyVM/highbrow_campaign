<?php

namespace App\Http\Controllers;

use App\Department;
use Illuminate\Http\Request;

class DepartmentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
	 public function view()
	 {
		//$unm = $request->session()->get('username');
		//$users=Register::all();
        $depts = Department::all();
		//$users = DB::select('select * from registers')->get();
		 //$users=DB::table('registers')->where(['email'=>$unm])->get();
      return view('admin.manage-department',compact('depts'));
	
		//$items = DB::table('registers')->get();
		//return view('admin.manage_student',compact('students'));
	 }
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $deptname=$request->input('deptname');
        $status=$request->input('status');
        $dept=new Department([
            
                'name'=>$request->get('deptname'),
               'status'=>$request->get('status'),
            ]);
            $dept->save();

        // $deptname = $request->input('deptname');
        // $status = $request->input('status');
        // DB::insert('insert into departments (name,status) values(?,?)',[$deptname,$status]);
            return redirect()->back()->with('success', 'Department Inserted Successfully');
    }
    public function getStates(Country $country)
    {
        return $department->courses()->select('id', 'name')->get();
    }
    /**
     * Display the specified resource.
     *
     * @param  \App\Department  $department
     * @return \Illuminate\Http\Response
     */
    public function show(Department $department)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Department  $department
     * @return \Illuminate\Http\Response
     */
    public function edit(Department $department)
    {
        $department=Department::find($id);
        return view('admin.edit-dept',compact('department'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Department  $department
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Department $department)
    {
        $department=Department::find($id);
	   //$students->firstname=$request->get('firstname');
	   //$students->lastname=$request->get('lastname');
		$department->name=$request->get('deptname');
	   $department->save();
	   return redirect('/edit-department');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Department  $department
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
          $data = Department::where('id', $id)->get();
        //$log = Login::find($loginid);
        foreach($data as $obj){
            if($obj -> status == 'active'){
                Department::where('id', $id)->update(['status'=> 'Inactive']);
               //  $user = Departemnt::where('id', $id)->select('uname')->get();
               //  Register::where('uname', $user[0]->uname)->update(['ustatus'=> 2]);
            }
            else if($obj -> status == 'Inactive'){

               Department::where('id',$id)->update(['status'=> 'active']);
               // $user = Login::where('loginid', $loginid)->select('uname')->get();
               // Register::where('uname', $user[0]->uname)->update(['ustatus'=> 1]);

            }
//         DB::table('departments')->where('id',$id)->update(array(
//             'status'=>'inactive',)); 

 return redirect('/edit-department');
		}
    }
}
