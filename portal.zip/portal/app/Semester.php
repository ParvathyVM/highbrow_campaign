<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Semester extends Model
{
    Public $fillable=['name','course_id'];
}
