<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Apptitude extends Model
{
    public $fillable=['question','opta','optb','optc','optd','dept','course','sem','dept_id','course_id','sem_id'];
}
