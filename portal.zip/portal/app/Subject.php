<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Subject extends Model
{
    public $fillable=['sub_code','sub_name','dept','course','sem','sub_status','dept_id','course_id','semester_id'];

}
