<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Allocation extends Model
{
    public $fillable=['duty','teacher_name','class','sub_name','sub_id','dept','course','sem',
    'allocation_status','dept_id','course_id','semester_id'];
}
