<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class notification extends Model
{
    public $fillable=['dept','course','sem','notification','status'];
}
