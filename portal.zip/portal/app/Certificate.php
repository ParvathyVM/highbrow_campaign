<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Certificate extends Model
{
    public $fillable=[
        'email',
        'certificate',
		'date',
		'reason',
		'status',
		];
}
