<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateRegistersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('registers', function (Blueprint $table) {
            $table->bigIncrements('id');
			$table->string('reg_no')->unique;
			$table->string('fname');
			$table->string('lname');
			$table->date('dob');
			$table->string('gender');
			$table->date('adm_date');
			$table->String('pass_date');
			$table->string('house_name');
			$table->string('place');
			$table->string('district');
			$table->string('state');
			$table->string('country');
			//$table->string('pincode');
			$table->string('mobile');
			$table->string('email')->unique;
			
			$table->string('tenth');
			$table->string('plus_two');
			$table->string('degree');
			$table->string('department');
			$table->string('stream');
			$table->string('semester');
			
			$table->string('image');
			$table->string('username');
			$table->string('password');
			$table->string('status');
			
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('registers');
    }
}
