<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateParentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('parents', function (Blueprint $table) {
           
           $table->bigIncrements('id');
			
			$table->string('fname');
			$table->string('lname');
			//$table->date('dob');
			$table->string('gender');
			$table->string('adm_no');
			$table->string('student');
			$table->string('house_name');
			$table->string('place');
			$table->string('country');
			$table->string('state');
			$table->string('district');
			$table->string('occupation');
			$table->string('mobile');
			$table->string('email')->unique;
			//$table->string('duty');
			//$table->string('sclass');
			$table->string('image');
			$table->string('password');
			$table->string('status');
            $table->timestamps();
     
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('parents');
    }
}
