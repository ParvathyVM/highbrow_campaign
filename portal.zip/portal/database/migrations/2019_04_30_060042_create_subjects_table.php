<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateSubjectsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('subjects', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('sub_code');
            $table->string('sub_name');
            $table->string('dept'); 
            $table->string('course');
            $table->string('sem');
            $table->string('sub_status');     
            $table->integer('dept_id')->unsigned();
            $table->foreign('dept_id')->references('id')->on('departments');    
            $table->integer('course_id')->unsigned();
            $table->foreign('course_id')->references('id')->on('courses');     
            $table->integer('semester_id')->unsigned();
            $table->foreign('semester_id')->references('id')->on('semesters');                   
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('subjects');
    }
}
