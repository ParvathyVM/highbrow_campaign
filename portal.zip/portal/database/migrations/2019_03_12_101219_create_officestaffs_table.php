<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateOfficestaffsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('officestaffs', function (Blueprint $table) {
             $table->bigIncrements('id');
			//$table->string('reg_no')->unique;
			$table->string('fname');
			$table->string('lname');
			$table->date('dob');
			$table->string('gender');
			$table->date('join_date');
			$table->string('department');
			$table->string('designation');
			$table->string('house_name');
			$table->string('place');
			$table->string('country');
			$table->string('state');
			$table->string('district');
			
			
			$table->string('qualification');
			$table->string('mobile');
			$table->string('email')->unique;
			
			$table->string('password');
			$table->string('status');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('officestaffs');
    }
}
