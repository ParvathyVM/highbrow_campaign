<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		 <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

		<title>Highbrow Campaigns</title>

		<!-- Google font -->
		<link href="https://fonts.googleapis.com/css?family=Lato:700%7CMontserrat:400,600" rel="stylesheet">

		<!-- Bootstrap -->
		<link type="text/css" rel="stylesheet" href="css/bootstrap.min.css"/>

		<!-- Font Awesome Icon -->
		<link rel="stylesheet" href="css/font-awesome.min.css">

		<!-- Custom stlylesheet -->
		<link type="text/css" rel="stylesheet" href="css/style.css"/>

		<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--[if lt IE 9]>
		  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
		  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
		<![endif]-->

    </head>
	<body>

		<!-- Header -->
		<header id="header" class="transparent-nav">
			<div class="container">

				<div class="navbar-header">
					<!-- Logo -->
					<div class="navbar-brand">
					<a class="logo" href="/">
							<h2><font color="white">Highbrow Campaigns</h2>
						</a>
					</div>
					<!-- /Logo -->

					<!-- Mobile toggle -->
					<button class="navbar-toggle">
						<span></span>
					</button>
					<!-- /Mobile toggle -->
				</div>

				<!-- Navigation -->
				<nav id="nav">
					<ul class="main-menu nav navbar-nav navbar-right">
						<li><a href="/">Home</a></li>
						<li><a href="/about">About</a></li>
						<li><a href="/history">History</a></li>
						<li><a href="/contact">Contact</a></li>
					</ul>
				</nav>
				<!-- /Navigation -->

			</div>
		</header>
		<!-- /Header -->

		<!-- Home -->
		<div id="home" class="hero-area">

			<!-- Backgound Image -->
			<div class="bg-image bg-parallax overlay" style="background-image:url(./img/home-background.jpg)"></div>
			<!-- /Backgound Image -->

			<div id="why-us" class="section">

			<!-- container -->
			<div class="container">

				<!-- row -->
				<div class="row">
					<div class="section-header text-center">
						<h2><font color="white">Highbrow Campaigns</font></h2>
						<p>&nbsp;</p>
						<p class="lead">An investment in knowledge pays the best interest</p>
					</div>

					<!-- feature -->
					<div class="col-md-4">
						<div class="feature">
							<i class="feature-icon fa fa-history"></i>
							<div class="feature-content">
								<h4><font color="white">HISTORY</font></h4>
								<p>Mangalam College of Engineering was founded in the year 2002 by late Mr. M. C. Varghese[11] (Founder Chairman of the Mangalam Group) as a private self-financing engineering college in Kerala. After the demise of Mr. M. C. Varghese, his son Mr. Biju Varghese was appointed as the Chairman of the institution. The college is located in Ettumanoor of Kottayam district in Kerala which spreads over an area of about 25 acres.</p>
							</div>
						</div>
					</div>
					<!-- /feature -->

					<!-- feature -->
					<div class="col-md-4">
						<div class="feature">
							<i class="feature-icon fa fa-user-o"></i>
							<div class="feature-content">
								<h4><font color="white">FOUNDER</font></h4>
								<p>Mangalam college established in April 1969 by Mr. M. C. Varghese, an extraordinary visionary with social commitment and dedication. The Mangalam Group initiated the project of publishing a weekly magazine that would quench the thirst of an average Malayalee reader. The success of Malayalam Weekly marked the dawn of an era in the publishing sector of Kerala, rewriting the publishing history in Asia (circulation of 1.5 million in 1984) and established a well-reputed household name Mangalam in India.</p>
							</div>
						</div>
					</div>
					<!-- /feature -->

					<!-- feature -->
					<div class="col-md-4">
						<div class="feature">
							<i class="feature-icon fa fa-bar-chart"></i>
							<div class="feature-content">
								<h4><font color="white">Legacy<font></h4>
							<p><img src="./img/legacy.png" alt=""></p>
							</div>
						</div>
					</div>
					<!-- /feature -->

				</div>
				<!-- /row -->

				
				<!-- row -->
				<div class="row">

				

					<!--<div class="col-md-5 col-md-offset-1">
						<a class="about-video" href="#">
							<img src="./img/about-video.jpg" alt="">
							<i class="play-icon fa fa-play"></i>
						</a>
					</div>-->

				</div>
				<!-- /row -->

			</div>
			<!-- /container -->

		</div>
		<!-- /Why us -->


		</div>
		

		<!-- jQuery Plugins -->
		<script type="text/javascript" src="js/jquery.min.js"></script>
		<script type="text/javascript" src="js/bootstrap.min.js"></script>
		<script type="text/javascript" src="js/main.js"></script>

	</body>
</html>
