<?php

Route::get('/', function () {
    return view('welcome');
});
Route::get('/about', function () {
    return view('about');
});
Route::get('/history', function () {
    return view('history');
});
Route::get('/contact', function () {
    return view('contact');
});
Route::get('/Login', function () {
    return view('Login');
});
Route::get('/studreg', function () {
    return view('studreg');
});
Route::get('/loginme', function () {
    return view('admin.home');
});
//Route::get('/loginme','LoginController@login');
Route::post('/loginme','LoginController@login');

//add student
Route::get('/reg', 'AdminController@addstudent');
Route::post('/add', 'RegisterController@store');
Route::get('/loginme', 'RegisterController@count');
//add teacher
Route::get('/addteacher', 'AdminController@addteacher');
Route::post('/teacheradd', 'TeacherController@store');

//add parent
Route::get('/addparent', 'AdminController@addparent');
Route::post('/parentadd', 'ParentsController@store');

//add staff
Route::get('/addstaff', 'AdminController@addstaff');
Route::post('/office', 'OfficestaffController@store');

Route::get('get-course-list','AdminController@getCourseList');
Route::get('get-stream-list','AdminController@getSemList');



Route::get('/send','MailController@index');
Route::post('/send/email','MailController@sendemail');


Route::post('/sendmail','MailController@send');

//add department
Route::get('/addept','AdminController@dept');
Route::post('adddept','DepartmentController@store');



//update department
Route::get('/edit-department','DepartmentController@view');
Route::get('/Updatedept/{id}','DepartmentController@destroy');//blocking the dept
Route::resource('Editdept','DepartmentController');

//block department
//Route::resource('blockdept', 'DepartmentController');
Route::get('blockdept/{id}','DepartmentController@destroy');


//Route::post('/editstudent', 'RegisterController@update');

//logout
Route::get('/logout', 'LoginController@logout');


//edit student
Route::get('/edit','RegisterController@view');
Route::resource('Edit','RegisterController');

//delete student
Route::get('deleten/{email}','RegisterController@destroy');


//edit staff
//Route::post('/editstaff', 'OfficestaffController@update');
Route::resource('Edit_staff','OfficestaffController');
Route::get('/update','OfficestaffController@view');

//delete staff
Route::get('delete/{email}','OfficestaffController@destroy');
//Route::get('/update','OfficestaffController@view');
//Route::get('/manage','RegisterController@view');

//edit teacher
Route::resource('Edit_teacher','TeacherController');
Route::get('/manage','TeacherController@view');

//delete teacher
Route::get('deletet/{email}','TeacherController@destroy');

//edit parent
Route::resource('Edit_parent','ParentsController');
Route::get('/modify','ParentsController@view');

//delete parents
Route::get('deletep/{email}','ParentsController@destroy');

//course
Route::get('/add-course','CourseController@myform');
Route::post('addcourse','CourseController@store');
Route::get('/edit-course','CourseController@view');
Route::resource('Editcourse','CourseController');
Route::get('/Updatecourse/{id}','CourseController@destroy');//blocking the course
//Route::resource('blockdept', 'DepartmentController');
Route::get('blockcourse/{id}','CourseController@destroy');

//subject
Route::get('/add-subject','SubjectController@index');
Route::post('/addsub','SubjectController@store');
Route::get('get-course-list','SubjectController@getCourseList');
Route::get('get-stream-list','SubjectController@getStreamList');


//Route::get('/Updatesubject/{id}','SubjectController@destroy');
Route::resource('Editsubject','SubjectController');

//all students
Route::get('/all_students','AllStudentsController@index');
Route::get('getcourse','AllStudentsController@getCourseList');
Route::post('/search','AllStudentsController@search');

//all faculty
Route::get('/all_faculties','AllFacultiesController@index');
//Route::get('/search','AllFacultiesController@search');

//country_state_district
Route::get('dropdownlist','DropdownController@index');
Route::get('get-state-list','AdminController@getStateList');
Route::get('get-city-list','AdminController@getCityList');
// Route::get('getcourselist','AdminController@getCourseList');
// Route::get('getstreamlist','AdminController@getSemList');
Route::get('get-state-list','AdminController@getStateListt');
Route::get('get-city-list','AdminController@getCityListt');

Route::get('get-state-list','AdminController@getStateListos');
Route::get('get-city-list','AdminController@getCityListos');

Route::get('get-state-list','AdminController@getStateListp');
Route::get('get-city-list','AdminController@getCityListp');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

//faculty home
Route::get('/Log','TeacherController@count2');

//profile 
Route::post('/pro', 'MyProfileController@profile1');
Route::post('/editfac', 'MyProfileController@profileedit');
Route::get('/profilef', 'MyProfileController@profile_edit');
Route::post('/editprofilef', 'MyProfileController@haiii');
Route::post('/editprofile1f', 'MyProfileController@update');
//student profile
Route::post('/pro', 'StudentprofileController@profile1');
Route::post('/editfac', 'StudentprofileController@profileedit');
Route::get('/profile1', 'StudentprofileController@profile_edit');
Route::post('/editprofile2', 'StudentprofileController@haiii');
Route::post('/editprofile11', 'StudentprofileController@update');


//payment
Route::get('/pay1', 'PayController@view');
Route::any('/payment', 'PayController@store');
Route::any('/status', 'PayController@show');
Route::any('/balance', 'PayController@due');
Route::any('/certi', 'CertificateController@show');
Route::get('/approval/{email}/{status}','CertificateController@des');
//staff profile
Route::post('/pro', 'StaffprofileController@profile1');
Route::post('/editfac', 'StaffprofileController@profileedit');
Route::get('/profile', 'StaffprofileController@profile_edit');
Route::post('/editprofile', 'StaffprofileController@haiii');
Route::post('/editprofile1', 'StaffprofileController@update');

//parent profile

Route::get('/self', 'ParentprofileController@profile_edit');
Route::any('/editprofilep', 'ParentprofileController@haiii');
Route::post('/editprofilep1', 'ParentprofileController@update');


Route::any('/sstudss','ExamresultController@parentshow');
//question upload
Route::get('/upload','QuestionUploadController@index');
Route::get('courselist','QuestionUploadController@getCourseList');
Route::get('streamlist','QuestionUploadController@getStreamList');
Route::get('subjectlist','QuestionUploadController@getSubjectList');
Route::post('/questupload','QuestionUploadController@store');
Route::resource('Editsubject','SubjectController');
Route::get('/managesub','SubjectController@view');



//notes upload
Route::get('/uploadnotes','NoteController@index');
Route::get('courselist','NoteController@getCourseList');
Route::get('streamlist','NoteController@getStreamList');
Route::get('subjectlist','NoteController@getSubjectList');
Route::post('/noteupload','NoteController@store');
Route::get('country/{country}/states', 'CountryController@getStates');
//question student
//Route::get('/viewqp','QuestionUploadController@papers');
//Route::post('/questupload','QuestionUploadController@store');

//question student
//Route::get('/viewqp','NoteController@papers');

//notification upload
Route::get('/uploadn','NotificationController@index');
Route::get('courselist','NotificationController@getCourseList');
Route::get('streamlist','NotificationController@getStreamList');
Route::get('subjectlist','NotificationController@getSubjectList');
Route::post('/notiupload','NotificationController@store');
Route::get('/mangenoti','NotificationController@view');
Route::Resource('Editnoti','NotificationController');

//event upload
Route::get('/uploade','EventController@index');
Route::get('/managevent','EventController@view');
Route::get('courselist','EventController@getCourseList');
Route::get('streamlist','EventController@getStreamList');
Route::get('subjectlist','EventController@getSubjectList');
Route::post('/eventupload','EventController@store');
Route::Resource('Editevent','EventController');




//mark upload
Route::get('/uploadmark','UploadmarkController@index');
Route::post('/search1','UploadmarkController@sea');
Route::post('/set','UploadmarkController@store');
Route::get('get-course-list','UploadmarkController@getCourseList');
Route::get('get-stream-list','UploadmarkController@getStreamList');
Route::get('getsubjectlist','UploadmarkController@getSubjectList');

//leave
Route::get('/leave','LeaveReasonController@index');
Route::post('/rea','LeaveReasonController@store');

//certificate
Route::get('/certificate','CertificateController@index');
Route::post('/apply','CertificateController@store');

//leave approval
Route::get('/approval','LeaveReasonController@view');
//Route::post('/rea','LeaveReasonController@store');


//allocation
Route::get('/allocate','AllocationController@view');
Route::get('get-subject-list','AllocationController@getSubjectList');
Route::get('get-course-list','AllocationController@getCourseList');
Route::get('get-stream-list','AllocationController@getStreamList');
Route::post('/classallocate','AllocationController@store');

//student.questionpaper
Route::get('/pre','ExamresultController@index');
Route::post('/s1','ExamresultController@seas1');
Route::get('/note','DropdownController@index3');
Route::get('/viewqp','DropdownController@indexquest');

Route::get('/shownoti','DropdownController@indexnoti');
Route::get('/showevent','DropdownController@indexevent');
Route::get('getcourselist','DownloadController@getCourseList');
Route::get('getstreamlist','DownloadController@getStreamList');
//Route::post('/previous','DownloadController@search');




// Teacher Student
Route::get('/searchreport','ReportController@index');
Route::post('/se5','ReportController@search5');
Route::post('/set','UploadmarkController@store');


//leave approve
Route::get('/Updateleave/{id}','LeavereasonController@des');
Route::resource('Editleave','LeavereasonController');
Route::get('/leavestatus','LeaveReasonController@view2');

//pay
Route::get('/pay','PaymentController@index');
Route::get('courselist','PaymentController@getCourseList');
Route::get('streamlist','PaymentController@getStreamList');
Route::post('/sendnote','PaymentController@create');


Route::get('/addset','ApptitudesController@index');